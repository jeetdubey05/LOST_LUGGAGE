CREATE DATABASE LUGGAGE_DATABASE;
USE LUGGAGE_DATABASE;
CREATE TABLE parcels (
                         parcel_id INT PRIMARY KEY AUTO_INCREMENT,
                         sender VARCHAR(100),
                         receiver VARCHAR(100),
                         destination VARCHAR(100),
                         weight_kg DECIMAL(5,2),
                         booked_on DATETIME DEFAULT CURRENT_TIMESTAMP,
                         status ENUM('booked', 'in transit', 'arrived', 'claimed') DEFAULT 'booked'
);
