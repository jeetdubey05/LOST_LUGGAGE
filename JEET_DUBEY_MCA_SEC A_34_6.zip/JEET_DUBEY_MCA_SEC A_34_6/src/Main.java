
import java.sql.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws SQLException {
        Scanner sc=new Scanner(System.in);
        Connection con= DBConnection.getConnection();
        while(true){
            // User Menu
            System.out.println("======== PARCEL TRACKER ========");
            System.out.println("press 1: register parcel ");
            System.out.println("press 2: update status ");
            System.out.println("press 3: search parcel");
            System.out.println("press 4: view unclaimed( 3+ days)");
            System.out.println("press 5: Exit");
            // taking choice as a Input
            System.out.print("Enter your choice: ");
            int choice =sc.nextInt();
            switch (choice){
               // register Parcel into the data Base
                case 1:
                    sc.nextLine();
                    try {
                        System.out.println("Enter sender Name");
                        String sender=sc.nextLine();
                        System.out.println("Enter Receiver name");
                        String receiver=sc.nextLine();
                        System.out.println("Enter the Destination of parcel ");
                        String destination=sc.nextLine();

                        System.out.println("Enter the weight of parcel");
                        double weight=sc.nextDouble();

                        PreparedStatement pt=con.prepareStatement("insert into parcels(sender,receiver,destination,weight_kg) values(?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
                        pt.setString(1,sender);
                        pt.setString(2,receiver);
                        pt.setString(3,destination);
                        pt.setDouble(4,weight);

                        System.out.println("DATA INSERTED SUCCESSFULLY...");
                        int res=pt.executeUpdate();
                        ResultSet rs=pt.getGeneratedKeys();
                        if(rs.next()){
                            int id=rs.getInt(1);
                            System.out.println("your generated parcel id :"+id);
                        }


                    }catch (Exception e){
                        e.printStackTrace();
                        System.out.println("DATA not Inserted");
                    }
                    break;
                // Updating the status of Parcel
                case 2:
                    sc.nextLine();
                    System.out.print("Enter the ID of parcel to update status:");
                    int pId= sc.nextInt();
                    sc.nextLine();
                    System.out.println("enter the status of the parcel");
                    String status=sc.nextLine();

                    PreparedStatement pt=con.prepareStatement("UPDATE parcels set status=? where parcel_id=?");
                    pt.setString(1,status);
                    pt.setInt(2,pId);
                    pt.executeUpdate();
                    System.out.println("SUCCESSFULLY UPDATED STATUS...");

                    break;
                 // Searching the Parcel
                case 3:

                    sc.nextLine();
                    System.out.print("Enter the ID of parcel to Search:");
                    int pid= sc.nextInt();
                    sc.nextLine();

                    PreparedStatement pb=con.prepareStatement("SELECT * from parcels where  parcel_id=?");
                    pb.setInt(1,pid);

                    ResultSet rs=pb.executeQuery();
                    System.out.println("SEARCH RESULT...");
                    if(rs.next()){
                        System.out.println("SENDER:"+rs.getString("sender")+" | "+"RECEIVER:"
                                +rs.getString("receiver")+" | "+"DEST:"+rs.getString("destination")+
                                " | DATE :"+rs.getDate("booked_on")+" | weight: "+rs.getBigDecimal("weight_kg")+" | Status:"+rs.getString("status"));

                    }
                    else {
                        System.out.println("NO SUCH PACKAGE FOUND WITH ID:"+pid);
                    }
                    break;
                //retreiving Parcel Details which are Booked 3+ and Uncliamed
                case 4:
                    PreparedStatement pr=con.prepareStatement("SELECT * FROM parcels WHERE booked_on < (CURRENT_DATE - INTERVAL 3 DAY) AND status <> 'claimed';");
                    ResultSet rp=pr.executeQuery();
                    System.out.println("SEARCH RESULT...");
                    while(rp.next()){
                        System.out.println("SENDER:"+rp.getString("sender")+" | "+"RECEIVER:"
                                +rp.getString("receiver")+"|"+"DEST:"+rp.getString("destination")+
                                "| DATE :"+rp.getDate("booked_on")+" | weight: "+rp.getBigDecimal("weight_kg")+"| Status:"+rp.getString("status"));
                    }
                    break;
                //Existing from System
                case 5:
                    System.out.println("CLOSING THE SYSTEM...");
                    System.exit(0);

            }
        }
    }

}